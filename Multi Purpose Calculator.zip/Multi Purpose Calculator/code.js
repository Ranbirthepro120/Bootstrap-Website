onEvent("button1", "click", function( ) {
  setScreen("Weight_Converter");
});
onEvent("button2", "click", function( ) {
  setScreen("Temperature_Converter");
});
onEvent("button3", "click", function( ) {
  setScreen("Volume_Converter");
});
onEvent("button4", "click", function( ) {
  setScreen("Distance_Converter");
});
onEvent("button5", "click", function( ) {
  setScreen("Pounds_to_Kilograms");
});
onEvent("button6", "click", function( ) {
  setScreen("Kilograms_to_Pounds");
});
onEvent("image4", "click", function( ) {
  setScreen("Home_Screen");
});
onEvent("image3", "click", function( ) {
  setScreen("Home_Screen");
});
onEvent("button9", "click", function( ) {
  setScreen("Fahrenheit_to_Celsius");
});
onEvent("button10", "click", function( ) {
  setScreen("Celsius_to_Fahrenheit");
});
onEvent("image6", "click", function( ) {
  setScreen("Home_Screen");
});
onEvent("image8", "click", function( ) {
  setScreen("Home_Screen");
});
onEvent("image11", "click", function( ) {
  setScreen("Home_Screen");
});
onEvent("image9", "click", function( ) {
  setScreen("Home_Screen");
});
onEvent("button14", "click", function( ) {
  setScreen("Feet_to_Meters");
});
onEvent("button15", "click", function( ) {
  setScreen("Meters_to_Feet");
});
onEvent("image", "click", function( ) {
  setScreen("Home_Screen");
});
onEvent("image16", "click", function( ) {
  setScreen("Home_Screen");
});
onEvent("button13", "click", function( ) {
  setScreen("Mph_to_Kph");
});
onEvent("button18", "click", function( ) {
  setScreen("Kph_to_Mph");
});
onEvent("image12", "click", function( ) {
  setScreen("Home_Screen");
});
onEvent("button25", "click", function( ) {
  setScreen("Gallons_to_Liters");
});
onEvent("button26", "click", function( ) {
  setScreen("Liters_to_Gallons");
});
onEvent("button21", "click", function( ) {
  setScreen("Mps_to_Kph");
});
onEvent("button22", "click", function( ) {
  setScreen("Kph_to_Mps");
});
onEvent("image10", "click", function( ) {
  setScreen("Home_Screen");
});
onEvent("image.", "click", function( ) {
  setScreen("Home_Screen");
});
onEvent("image18", "click", function( ) {
  setScreen("Home_Screen");
});
onEvent("button7", "click", function( ) {
  setText("text_input3", getNumber("text_input2") / 2.205);
});
onEvent("button8", "click", function( ) {
  setText("text_input4", getNumber("text_input1") * 2.205);
});
onEvent("button11", "click", function( ) {
  setText("text_input6", getNumber("text_input5") - 32);
  setText("text_input6", getNumber("text_input6") * 5);
  setText("text_input6", getNumber("text_input6") / 9);
});
onEvent("button12", "click", function( ) {
  setText("text_input8", getNumber("text_input7") / 5);
  setText("text_input8", getNumber("text_input8") * 9);
  setText("text_input8", getNumber("text_input8") + 32);
});
onEvent("button16", "click", function( ) {
  setText("text_input10", getNumber("text_input9") * 3.281);
});
onEvent("button17", "click", function( ) {
  setText("text_input12", getNumber("text_input11") / 3.281);
});
onEvent("button19", "click", function( ) {
  setText("text_input14", getNumber("text_input13") * 1.609);
});
onEvent("button20", "click", function( ) {
  setText("text_input16", getNumber("text_input15") / 1.609);
});
onEvent("button23", "click", function( ) {
  setText("text_input18", getNumber("text_input17") * 3.6);
});
onEvent("button24", "click", function( ) {
  setText("text_input20", getNumber("text_input19") / 3.6);
});
onEvent("button27", "click", function( ) {
  setText("text_input22", getNumber("text_input21") * 3.785);
});
onEvent("button28", "click", function( ) {
  setText("text_input24", getNumber("text_input23") / 3.785);
});
